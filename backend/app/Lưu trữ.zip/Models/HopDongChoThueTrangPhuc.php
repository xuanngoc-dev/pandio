<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'ma_hop_dong',
    'ten_khach_hang',
    'sdt_khach_hang',
    'ngay_thue',
    'ngay_tra_du_kien',
    'ngay_tra_chinh_thuc',
    'so_ngay_thue',
    'tong_tien',
    'giam_gia',
    'thanh_tien',
    'tien_coc',
    'tong_tien_thanh_toan',
    'phi_tra_muon',
    'tien_den_bu',
    'phi_phu_thu',
    'uu_dai_tat_toan',
    'hinh_thuc_thanh_toan',
    'trang_thai',
    'nguoi_cho_thue',
    'nguoi_tham_gia',
    'ghi_chu_sale',
    'ghi_chu_khach',
])]
class HopDongChoThueTrangPhuc extends Model
{
    protected $table = 'hop_dong_cho_thue_trang_phuc';

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'ngay_thue' => 'date',
            'ngay_tra_du_kien' => 'date',
            'ngay_tra_chinh_thuc' => 'date',
            'so_ngay_thue' => 'integer',
            'tong_tien' => 'integer',
            'giam_gia' => 'integer',
            'thanh_tien' => 'integer',
            'tien_coc' => 'integer',
            'tong_tien_thanh_toan' => 'integer',
            'phi_tra_muon' => 'integer',
            'tien_den_bu' => 'integer',
            'phi_phu_thu' => 'integer',
            'uu_dai_tat_toan' => 'integer',
            'nguoi_tham_gia' => 'array',
        ];
    }

    /**
     * Sinh mã hợp đồng theo quy tắc: HDTTP_DDMMYYYY{id}
     */
    public static function buildMaHopDong(int $id, ?\DateTimeInterface $date = null): string
    {
        $date ??= now();

        return 'HDTTP_'.$date->format('dmY').$id;
    }

    public function nguoiChoThueUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'nguoi_cho_thue');
    }

    public function sanPhamChoThue(): HasMany
    {
        return $this->hasMany(HopDongChoThueTrangPhucSanPhamChoThue::class, 'hop_dong_id');
    }
}
